package ontap;

public interface rate {
	public int rate();
}

interface weight{
	public int weight();
}